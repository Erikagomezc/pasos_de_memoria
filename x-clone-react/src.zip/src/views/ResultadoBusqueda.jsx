import { useState } from 'react'; 
import logo from "C:/x-clone-react/logo1.png";

function TabbedTemplate() {
  const [activeTab, setActiveTab] = useState('inicio');
  const changeTab = (tab) => {
    setActiveTab(tab);
  };

  // Ejemplos de datos para las tablas
  const medicamentos = [
    { nombre: 'Paracetamol', dosis: '500mg', frecuencia: 'Cada 8 horas' },
    { nombre: 'Ibuprofeno', dosis: '400mg', frecuencia: 'Cada 6 horas' },
    { nombre: 'Loratadina', dosis: '10mg', frecuencia: 'Una vez al día' }
  ];

  const centrosSalud = [
    { nombre: 'Centro de Salud A', direccion: 'Calle 123, Ciudad A' },
    { nombre: 'Hospital B', direccion: 'Avenida 456, Ciudad B' },
    { nombre: 'Clínica C', direccion: 'Calle 789, Ciudad C' }
  ];

  const historialUbicaciones = [
    { fecha: '2024-11-01', ubicacion: 'Calle 123, Ciudad A' },
    { fecha: '2024-11-05', ubicacion: 'Avenida 456, Ciudad B' },
    { fecha: '2024-11-08', ubicacion: 'Calle 789, Ciudad C' }
  ];

  const tutorInfo = [
    { nombre: 'Juan Pérez', telefono: '123-456-7890', direccion: 'Calle Ficticia 321, Ciudad D', parentesco: 'Hijo' },
    { nombre: 'Ana Gómez', telefono: '987-654-3210', direccion: 'Avenida Imaginaria 654, Ciudad E', parentesco: 'Hermana' },
    { nombre: 'Carlos Rodríguez', telefono: '456-789-0123', direccion: 'Calle Real 987, Ciudad F', parentesco: 'Esposa' }
  ];

  const familiaConocido = [
    { cedula: '12345678', nombre: 'Laura López', parentesco: 'Tía', telefono: '321-654-0987', direccion: 'Calle 123, Ciudad G', esTutor: 'No' },
    { cedula: '87654321', nombre: 'Carlos Méndez', parentesco: 'Padre', telefono: '789-012-3456', direccion: 'Avenida 456, Ciudad H', esTutor: 'Sí' },
    { cedula: '11223344', nombre: 'María Jiménez', parentesco: 'Prima', telefono: '654-321-9870', direccion: 'Calle 789, Ciudad I', esTutor: 'No' }
  ];

  return (
    <div className="w-screen h-screen flex flex-col items-center bg-gradient-to-r from-blue-200 via-purple-200 to-green-200">
      {/* Logo de la plataforma */}
      <div className="mt-8 flex justify-center">
        <img src={logo} alt="Logo de la plataforma" className="w-64 h-auto rounded-full border-4 border-gray-300 mb-4" />
      </div>
      
      {/* Títulos de la plataforma */}
      <h1 className="text-4xl font-extrabold text-center text-gray-800 font-serif mb-4">Resultado de Búsqueda</h1>
      <h2 className="text-2xl font-bold text-center text-gray-700 mb-8">Búsqueda de Información</h2>

      {/* Barra de navegación con pestañas */}
      <ul className="flex justify-center space-x-8 mb-4">
        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'HistorialBusqueda' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-300 hover:bg-purple-400'}`}
            onClick={() => changeTab('HistorialBusqueda')}
          >
            Historial de Búsqueda
          </button>
        </li>
  
        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'Medicamentos' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-300 hover:bg-purple-400'}`}
            onClick={() => changeTab('Medicamentos')}
          >
            Medicamentos
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'CentroSalud' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-300 hover:bg-purple-400'}`}
            onClick={() => changeTab('CentroSalud')}
          >
            Centro de Salud
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'TutorInfo' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-300 hover:bg-purple-400'}`}
            onClick={() => changeTab('TutorInfo')}
          >
            Información del Tutor
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'FamiliaConocido' ? 'bg-purple-600 hover:bg-purple-700' : 'bg-purple-300 hover:bg-purple-400'}`}
            onClick={() => changeTab('FamiliaConocido')}
          >
            Familia o Conocido
          </button>
        </li>
      </ul>

      {/* Contenido de las pestañas */}
      <div className="w-full bg-white p-6 rounded-lg shadow-md mt-6">
        {activeTab === 'HistorialBusqueda' && (
          <div>
            <h3 className="text-xl font-bold mb-4">Historial de Ubicaciones</h3>
            <table className="min-w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Fecha</th>
                  <th className="px-4 py-2 border">Ubicación</th>
                </tr>
              </thead>
              <tbody>
                {historialUbicaciones.map((item, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{item.fecha}</td>
                    <td className="px-4 py-2 border">{item.ubicacion}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'Medicamentos' && (
          <div>
            <h3 className="text-xl font-bold mb-4">Ejemplos de Medicamentos</h3>
            <table className="min-w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Medicamento</th>
                  <th className="px-4 py-2 border">Dosis</th>
                  <th className="px-4 py-2 border">Frecuencia</th>
                </tr>
              </thead>
              <tbody>
                {medicamentos.map((med, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{med.nombre}</td>
                    <td className="px-4 py-2 border">{med.dosis}</td>
                    <td className="px-4 py-2 border">{med.frecuencia}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'CentroSalud' && (
          <div>
            <h3 className="text-xl font-bold mb-4">Centros de Salud</h3>
            <table className="min-w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Centro de Salud</th>
                  <th className="px-4 py-2 border">Dirección</th>
                </tr>
              </thead>
              <tbody>
                {centrosSalud.map((centro, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{centro.nombre}</td>
                    <td className="px-4 py-2 border">{centro.direccion}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'TutorInfo' && (
          <div>
            <h3 className="text-xl font-bold mb-4">Información del Tutor</h3>
            <table className="min-w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Nombre</th>
                  <th className="px-4 py-2 border">Teléfono</th>
                  <th className="px-4 py-2 border">Dirección</th>
                  <th className="px-4 py-2 border">Parentesco</th>
                </tr>
              </thead>
              <tbody>
                {tutorInfo.map((tutor, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{tutor.nombre}</td>
                    <td className="px-4 py-2 border">{tutor.telefono}</td>
                    <td className="px-4 py-2 border">{tutor.direccion}</td>
                    <td className="px-4 py-2 border">{tutor.parentesco}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'FamiliaConocido' && (
          <div>
            <h3 className="text-xl font-bold mb-4">Familia o Conocido</h3>
            <table className="min-w-full table-auto">
              <thead>
                <tr>
                  <th className="px-4 py-2 border">Cédula</th>
                  <th className="px-4 py-2 border">Nombre</th>
                  <th className="px-4 py-2 border">Parentesco</th>
                  <th className="px-4 py-2 border">Teléfono</th>
                  <th className="px-4 py-2 border">Dirección</th>
                  <th className="px-4 py-2 border">Es Tutor</th>
                </tr>
              </thead>
              <tbody>
                {familiaConocido.map((fam, index) => (
                  <tr key={index}>
                    <td className="px-4 py-2 border">{fam.cedula}</td>
                    <td className="px-4 py-2 border">{fam.nombre}</td>
                    <td className="px-4 py-2 border">{fam.parentesco}</td>
                    <td className="px-4 py-2 border">{fam.telefono}</td>
                    <td className="px-4 py-2 border">{fam.direccion}</td>
                    <td className="px-4 py-2 border">{fam.esTutor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default TabbedTemplate;
