// qr.jsx
import { useState } from "react";
import qrImage from "C:/x-clone-react/qr.png";  // Importa la imagen del QR desde la carpeta local

function QRPage() {
  // Estado para los datos de la persona
  const [personData] = useState({
    nombre: "Juan Pérez",
    cedula: "12345678",
    nombreTutor: "Carlos Pérez",
    telefonoTutor: "555-1234",
    observaciones: "Paciente con Alzheimer en etapa leve"
  });

  // Estado para controlar la visibilidad de la imagen QR
  const [showQR, setShowQR] = useState(false);

  // Función para mostrar el QR
  const handleGenerateQR = () => {
    setShowQR(true); // Cambia el estado para mostrar la imagen
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Generar Código QR</h2>

      {/* Mostrar los datos de la persona */}
      <div className="mb-4">
        <p><strong>Nombre:</strong> {personData.nombre}</p>
        <p><strong>Cédula:</strong> {personData.cedula}</p>
        <p><strong>Nombre del Tutor:</strong> {personData.nombreTutor}</p>
        <p><strong>Teléfono del Tutor:</strong> {personData.telefonoTutor}</p>
        <p><strong>Observaciones:</strong> {personData.observaciones}</p>
      </div>

      {/* Botón para generar QR */}
      <button
        onClick={handleGenerateQR}
        className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
      >
        Generar QR
      </button>

      {/* Mostrar la imagen QR si el estado showQR es true */}
      {showQR && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold">Código QR Generado:</h3>
          <img
            src={qrImage}  // Muestra la imagen importada
            alt="Código QR"
            className="mt-2 w-49 h-49"  // Ajusta el tamaño según sea necesario
          />
        </div>
      )}
    </div>
  );
}

export default QRPage;


