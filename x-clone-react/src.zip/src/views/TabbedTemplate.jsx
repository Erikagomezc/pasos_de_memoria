import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import RegistroPersona from './RegistroPersona';
import BuscarPersona from './BuscarPersona';
import QRPage from './qr';  // Importa la nueva página QR
import logo from "C:/x-clone-react/logo1.png";

function TabbedTemplate() {
  const { logout } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('inicio');
  const changeTab = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="w-screen h-screen flex flex-col items-center bg-gradient-to-r from-blue-200 via-purple-200 to-green-200">
      {/* Logo de la plataforma */}
      <div className="mt-8 flex justify-center">
        <img src={logo} alt="Logo de la plataforma" className="w-64 h-auto rounded-full border-4 border-gray-300 mb-4" />
      </div>
      
      {/* Títulos de la plataforma */}
      <h1 className="text-4xl font-extrabold text-center text-gray-800 font-serif mb-4">Pasos de Memoria</h1>
      <h2 className="text-2xl font-bold text-center text-gray-700 mb-8">SERVICIO DE INTERVENCIÓN DE DEAMBULACIÓN: BÚSQUEDA DE INFORMACIÓN PARA PERSONAS CON ALZHEIMER</h2>

      {/* Barra de navegación con pestañas */}
      <ul className="flex justify-center space-x-8 mb-4">
        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'Agregar Persona' ? 'bg-purple-500' : 'bg-blue-300 hover:bg-blue-400'}`}
            onClick={() => changeTab('Agregar Persona')}
          >
            Agregar Persona
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'BuscarPersona' ? 'bg-purple-500' : 'bg-blue-300 hover:bg-blue-400'}`}
            onClick={() => changeTab('BuscarPersona')}
          >
            Buscar Persona
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'Generar QR' ? 'bg-purple-500' : 'bg-blue-300 hover:bg-blue-400'}`}
            onClick={() => changeTab('Generar QR')}
          >
            Generar QR
          </button>
        </li>

        <li>
          <button
            className={`px-6 py-2 rounded-full text-white ${activeTab === 'CerrarSesion' ? 'bg-purple-500' : 'bg-blue-300 hover:bg-blue-400'}`}
            onClick={logout}
          >
            Cerrar Sesión
          </button>
        </li>
      </ul>

      {/* Contenido de las pestañas */}
      <div className="w-full bg-white p-6 rounded-lg shadow-md mt-6">
        {activeTab === 'Agregar Persona' && <RegistroPersona />}
        {activeTab === 'BuscarPersona' && <BuscarPersona />}
        {activeTab === 'Generar QR' && <QRPage />}  {/* Renderiza la página QR cuando se selecciona la pestaña */}
      </div>
    </div>
  );
}

export default TabbedTemplate;

