import React, { useContext } from 'react';
import { AuthContext } from "../context/AuthContext";

import andrea from "../assets/images/andrea.png";
import angie from "../assets/images/angie.png";
import allisson from "../assets/images/allisson.png";
import erika from "../assets/images/erika.png";

const PageUser = () => {
  const { logout } = useContext(AuthContext);

  const soporteTecnico = [
    { name: 'Andrea Carolina Espinosa', role: 'Soporte Técnico', image: andrea, email: 'andrea@pasosm.com', phone: '316-456-7890' },
    { name: 'Angie Paola Triana', role: 'Jefa Ejecutiva', image: angie, email: 'angie@pasosm.com', phone: '321-654-0987' },
    { name: 'Allisson Rojas', role: 'Relaciones Públicas', image: allisson, email: 'allisson@pasosm.com', phone: '311-546-8790' },
    { name: 'Erika Gomez', role: 'Relaciones Públicas', image: erika, email: 'erika@.com', phone: '312-546-8790' },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center bg-gradient-to-r from-blue-200 via-purple-200 to-green-200 p-8">
      {/* Descripción de la Página */}
      <section id="descripcion" className="mb-12 w-full max-w-3xl bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-4xl font-bold mb-4 text-gray-800">Descripción</h2>
        <p className="text-gray-700">
          En "Pasos de Memoria" sabemos la importancia de proteger a quienes amamos y asegurar su bienestar. Nuestra plataforma está diseñada para facilitar el rastreo y localización de personas con Alzheimer en estado de deambulación, brindando una herramienta confiable y sencilla de utilizar.

A través de tecnología de un sistema de notificaciones instantáneas, "Pasos de Memoria" conecta a familiares, tutores y personas desconocidas que encuentran a alguien en estado de desorientación. Nuestra misión es garantizar que cada ser querido, sin importar donde se encuentre, siempre pueda regresar seguro a casa.

Con "Pasos de Memoria", damos un paso hacia la tranquilidad.
        </p>
      </section>

      {/* Objetivos */}
      <section id="objetivos" className="mb-12 w-full max-w-3xl bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-4xl font-bold mb-4 text-gray-800">Objetivos</h2>
        <ul className="list-disc pl-6 text-gray-700">
          <li className="mb-2">Fomentar una red de apoyo para donaciones de órganos y sangre entre mascotas.</li>
          <li className="mb-2">Ofrecer atención veterinaria especializada y solidaria para mascotas en necesidad.</li>
          <li className="mb-2">Facilitar el acceso a servicios médicos de alta calidad para mejorar la salud de las mascotas.</li>
        </ul>
      </section>

      {/* Sección de Soporte Técnico */}
      <section id="soporte-tecnico" className="mb-12 w-full max-w-3xl bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-4xl font-bold mb-4 text-gray-800">Soporte Técnico</h2>
        <div className="flex flex-wrap justify-center gap-8">
          {soporteTecnico.map((member, index) => (
            <div key={index} className="w-full sm:w-1/2 md:w-1/3 lg:w-1/4 p-6 bg-gray-50 rounded-lg shadow-md text-center">
              <img src={member.image} alt={member.name} className="w-32 h-32 object-cover rounded-full mb-4 border border-gray-300 mx-auto" />
              <h3 className="text-xl font-bold text-gray-800">{member.name}</h3>
              <p className="text-gray-600">{member.role}</p>
              <p className="text-gray-500">{member.email}</p>
              <p className="text-gray-500">{member.phone}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Sección de Contacto */}
      <section id="contacto" className="mb-12 w-full max-w-3xl bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-4xl font-bold mb-4 text-gray-800">Contacto</h2>
        <p className="text-gray-700">Para más información o asistencia, comunícate con nuestro equipo a través de los siguientes medios:</p>
        <ul className="list-none pl-0 mt-4 text-gray-700">
          <li>Email: contacto@pasosm.com</li>
          <li>Teléfono: +57 604 456 789</li>
        </ul>
      </section>

      <button className="bg-gradient-to-r from-blue-300 to-green-300 hover:from-purple-300 hover:to-blue-300 py-3 px-6 rounded-full text-white mt-6" onClick={logout}>
        Cerrar Sesión
      </button>
    </div>
  );
};

export default PageUser;

