import { Navigate, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import logo from "C:/x-clone-react/logo1.png";
import { useState } from 'react'; 

const USER = [
  {
    id: 1,
    username: "allisson",
    password: "121212",
    role: "admin"
  },
  {
    id: 2,
    username: "erika",
    password: "121212",
    role: "admin"
  },
  {
    id: 3,
    username: "andrea",
    password: "121212",
    role:"user"
  },
  {
    id: 4,
    username: "angie",
    password: "121212",
    role:"user"
  }
];

function Login() {
  const navigate = useNavigate();
  const { user, login } = useAuth();
  const [error, setError] = useState("");

  if (user) {
    return <Navigate to="/" />;
  }

  function handleSubmit(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);

    const loginObject = Object.fromEntries(formData.entries());
    const userLogin = USER.find((user) => 
      user.username === loginObject.username 
      && user.password === loginObject.password
    );
    if (userLogin) {
      login(userLogin.id);
      if (userLogin.role === "user") {
        navigate("/PageUser"); 
      } else if (userLogin.role === "admin") {
        navigate("/"); 
      }
    } else {
      setError("Nombre de usuario o contraseña incorrectos");
    }
  }

  return (
    <div className="w-screen h-screen flex justify-center items-center bg-gradient-to-r from-blue-200 via-purple-200 to-green-200">
      <div className="p-4">
        
        <div className="bg-white p-6 rounded-lg shadow-md w-[400px] flex flex-col items-center">
          <img src={logo} alt="Logo de la plataforma" className="mb-4 w-48 h-auto rounded-full border border-gray-300" />
          <h2 className="mb-6 font-bold text-2xl text-center text-gray-800">Bienvenido a Pasos de Memoria</h2>
          <form className="flex flex-col items-center" method="post" onSubmit={handleSubmit}>
            {error && <p className="text-red-500 mb-4">{error}</p>}

            <label htmlFor="username" className="text-black mb-6 text-left w-full">
              Iniciar Sesión 
            </label>

           
            <input
              className="mb-6 mx-auto rounded-md p-3 text-black bg-gray-300" 
              name="username"
              id="username"
              placeholder="Nombre de usuario"
              style={{ width: "350px" }}
            />
            
            
            <input
              className="mb-6 rounded-lg p-3 text-black bg-gray-300" 
              type="password"
              name="password"
              id="password"
              placeholder="Contraseña"
              style={{ width: "350px" }}
            />
            
            <button
              className="bg-gradient-to-r from-blue-300 to-green-300 hover:from-purple-300 hover:to-blue-300 py-2 px-4 rounded-full w-full mb-4 text-white"
              type="submit"
            >
              Inicia sesión
            </button>

            <Link className="text-purple-400 hover:underline" to="/register">
              Registro
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;

