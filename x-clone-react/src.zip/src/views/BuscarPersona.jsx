import { useState } from 'react'; 
import { useNavigate } from 'react-router-dom'; 

function CasosBusqueda() {
  const navigate = useNavigate(); 
  
  const [casos, setCasos] = useState([
    {
      id: 1,
      cedula: '12345678',
      nombre: 'Juan Pérez',
      fecha: '2023-11-15',
      hora: '09:00 AM',
      estado: 'Normal',
    },
    {
      id: 2,
      cedula: '23456789',
      nombre: 'María González',
      fecha: '2023-11-16',
      hora: '02:30 PM',
      estado: 'Deambulando',
    },
    {
      id: 3,
      cedula: '34567890',
      nombre: 'Carlos Rodríguez',
      fecha: '2023-11-17',
      hora: '11:15 AM',
      estado: 'Normal',
    },
  ]);

  const [nuevoCaso, setNuevoCaso] = useState({
    cedula: '',
    nombre: '',
    fecha: '',
    hora: '',
    estado: 'Normal',
  });

  const handleCrearCaso = () => {
    const newId = casos.length > 0 ? casos[casos.length - 1].id + 1 : 1;
    setCasos([...casos, { id: newId, ...nuevoCaso }]);
    setNuevoCaso({
      cedula: '',
      nombre: '',
      fecha: '',
      hora: '',
      estado: 'Normal',
    });
    
    
    navigate('/resultado-busqueda');
  };

  return (
    <div className="bg-white p-4">
      <h1 className="text-2xl font-bold mb-4">Gestión de Búsqueda de Clientes</h1>

      
      <div className="mb-4">
        <h2 className="text-xl font-bold mb-2">Ingrese los Datos del Cliente en Búsqueda</h2>
        <div className="flex flex-col space-y-4">
          <div className="flex flex-col">
            <label className="mb-2">Cédula:</label>
            <input
              type="text"
              value={nuevoCaso.cedula}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, cedula: e.target.value })}
              className="rounded-md p-2 border"
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-2">Nombre:</label>
            <input
              type="text"
              value={nuevoCaso.nombre}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, nombre: e.target.value })}
              className="rounded-md p-2 border"
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-2">Fecha:</label>
            <input
              type="date"
              value={nuevoCaso.fecha}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, fecha: e.target.value })}
              className="rounded-md p-2 border"
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-2">Hora:</label>
            <input
              type="time"
              value={nuevoCaso.hora}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, hora: e.target.value })}
              className="rounded-md p-2 border"
            />
          </div>
          <div className="flex flex-col">
            <label className="mb-2">Estado del Cliente:</label>
            <select
              value={nuevoCaso.estado}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, estado: e.target.value })}
              className="rounded-md p-2 border"
            >
              <option value="Normal">Normal</option>
              <option value="Deambulando">Deambulando</option>
            </select>
          </div>
        </div>
        <button
          onClick={handleCrearCaso}
          className="bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 py-2 px-4 rounded-full w-full mb-4"
          type="submit"
        >
          Ingresar Datos del Cliente en Búsqueda
        </button>
      </div>

      
      <div>
        <h2 className="text-xl font-bold mb-2">Clientes Registrados en el Sistema</h2>
        <table className="w-full border-collapse border">
          <thead>
            <tr className="bg-gray-200" style={{ backgroundColor: '#AEFFDB' }}>
              <th className="border p-2">ID</th>
              <th className="border p-2">Cédula</th>
              <th className="border p-2">Nombre</th>
              <th className="border p-2">Fecha</th>
              <th className="border p-2">Hora</th>
              <th className="border p-2">Estado</th>
            </tr>
          </thead>
          <tbody>
            {casos.map((caso) => (
              <tr key={caso.id} className="border">
                <td className="border p-2">{caso.id}</td>
                <td className="border p-2">{caso.cedula}</td>
                <td className="border p-2">{caso.nombre}</td>
                <td className="border p-2">{caso.fecha}</td>
                <td className="border p-2">{caso.hora}</td>
                <td className="border p-2">{caso.estado}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default CasosBusqueda;
