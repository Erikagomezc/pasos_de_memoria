import { useState } from 'react'; 

function RegistroCliente() {
  // Estados para los datos del cliente
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [cedula, setCedula] = useState('');
  const [direccion, setDireccion] = useState('');
  const [edad, setEdad] = useState('');
  const [genero, setGenero] = useState('');
  const [tipoSangre, setTipoSangre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [medicamentos, setMedicamentos] = useState('');
  const [enfermedadesBase, setEnfermedadesBase] = useState('');
  const [autorizacionDatos, setAutorizacionDatos] = useState(false);  // Cambiado a booleano
  const [documentos, setDocumentos] = useState(null);  // Inicializado en null para archivos
  const [historialUbicacion, setHistorialUbicacion] = useState('');
  const [centroSalud, setCentroSalud] = useState('');

  // Estados para la información del tutor/familiar
  const [nombreTutor, setNombreTutor] = useState('');
  const [cedulaTutor, setCedulaTutor] = useState('');
  const [parentescoTutor, setParentescoTutor] = useState('');
  const [telefonoTutor, setTelefonoTutor] = useState('');
  const [direccionTutor, setDireccionTutor] = useState('');
  const [esTutor, setEsTutor] = useState(false); // Cambiado a booleano

  const handleRegistroClick = () => {
    // Aquí se puede hacer lo que necesites con los datos
    console.log('Datos del Cliente:', { nombre, apellido, cedula, direccion, edad, genero, tipoSangre, descripcion, medicamentos, enfermedadesBase, autorizacionDatos, documentos, historialUbicacion, centroSalud });
    console.log('Datos del Tutor:', { nombreTutor, cedulaTutor, parentescoTutor, telefonoTutor, direccionTutor, esTutor });
  };

  return (
    <div>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', fontFamily: 'serif', textAlign: 'center' }}>
        Formulario de Registro
      </h1>
      <form>
        <div className="cliente-info">
          <h3 style={{ fontSize: '1rem', fontWeight: 'bold', fontFamily: 'serif', textAlign: 'center' }}>
            Datos del Cliente:
          </h3>
          <div className="mb-3">
            <label htmlFor="nombre" className="form-label">Nombre del Cliente</label>
            <input
              type="text"
              className="form-control"
              id="nombre"
              placeholder="Ingresar nombre completo del cliente"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="apellido" className="form-label">Apellido del Cliente</label>
            <input
              type="text"
              className="form-control"
              id="apellido"
              placeholder="Ingresar apellido del cliente"
              value={apellido}
              onChange={(e) => setApellido(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="cedula" className="form-label">Cédula del Cliente</label>
            <input
              type="text"
              className="form-control"
              id="cedula"
              placeholder="Ingresar cédula del cliente"
              value={cedula}
              onChange={(e) => setCedula(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="direccion" className="form-label">Dirección del Cliente</label>
            <input
              type="text"
              className="form-control"
              id="direccion"
              placeholder="Ingresar dirección completa del cliente"
              value={direccion}
              onChange={(e) => setDireccion(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="edad" className="form-label">Edad</label>
            <input
              type="text"
              className="form-control"
              id="edad"
              placeholder="Ingresar edad del cliente"
              value={edad}
              onChange={(e) => setEdad(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="genero" className="form-label">Género</label>
            <input
              type="text"
              className="form-control"
              id="genero"
              placeholder="Ingresar género del cliente"
              value={genero}
              onChange={(e) => setGenero(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="historialUbicacion" className="form-label">
              Historial de Ubicación
            </label>
            <textarea
              className="form-control"
              id="historialUbicacion"
              placeholder="Ingresar sitios recurrentes del cliente o donde se ha encontrado en caso de deambulación"
              value={historialUbicacion}
              onChange={(e) => setHistorialUbicacion(e.target.value)}
            />
          </div>
        </div>

        <div className="informacion-medica">
          <h3 style={{ fontSize: '1rem', fontWeight: 'bold', fontFamily: 'serif', textAlign: 'center' }}>
            Información Médica del Cliente:
          </h3>
          <div className="mb-3">
            <label htmlFor="tipoSangre" className="form-label">Tipo de Sangre</label>
            <input
              type="text"
              className="form-control"
              id="tipoSangre"
              placeholder="Ingresar tipo de sangre del cliente"
              value={tipoSangre}
              onChange={(e) => setTipoSangre(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="medicamentos" className="form-label">Medicamentos</label>
            <input
              type="text"
              className="form-control"
              id="medicamentos"
              placeholder="Ingresar medicamentos que usa el cliente"
              value={medicamentos}
              onChange={(e) => setMedicamentos(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="descripcion" className="form-label">
              Ingresar pequeña descripción médica del paciente
            </label>
            <textarea
              className="form-control"
              id="descripcion"
              placeholder="Descripción médica breve del cliente"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="enfermedadesBase" className="form-label">
              Ingresar enfermedades de base que presenta el cliente
            </label>
            <textarea
              className="form-control"
              id="enfermedadesBase"
              placeholder="Especificar enfermedades de base del cliente"
              value={enfermedadesBase}
              onChange={(e) => setEnfermedadesBase(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="centroSalud" className="form-label">Centro de Salud</label>
            <input
              type="text"
              className="form-control"
              id="centroSalud"
              placeholder="Ingresar centro de salud"
              value={centroSalud}
              onChange={(e) => setCentroSalud(e.target.value)}
            />
          </div>
        </div>

        <div className="informacion-familia">
          <h3 style={{ fontSize: '1rem', fontWeight: 'bold', fontFamily: 'serif', textAlign: 'center' }} >
            Información de Familia o Conocido:
          </h3>
          <div className="mb-3">
            <label htmlFor="nombreTutor" className="form-label">Nombre del Familiar o Conocido</label>
            <input
              type="text"
              className="form-control"
              id="nombreTutor"
              placeholder="Ingresar nombre del tutor o familiar"
              value={nombreTutor}
              onChange={(e) => setNombreTutor(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="cedulaTutor" className="form-label">Cédula del Familiar o Conocido</label>
            <input
              type="text"
              className="form-control"
              id="cedulaTutor"
              placeholder="Ingresar cédula del familiar"
              value={cedulaTutor}
              onChange={(e) => setCedulaTutor(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="parentescoTutor" className="form-label">Parentesco</label>
            <input
              type="text"
              className="form-control"
              id="parentescoTutor"
              placeholder="Ingresar parentesco con el cliente"
              value={parentescoTutor}
              onChange={(e) => setParentescoTutor(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="telefonoTutor" className="form-label">Teléfono del Familiar o Conocido</label>
            <input
              type="text"
              className="form-control"
              id="telefonoTutor"
              placeholder="Ingresar teléfono del tutor o familiar"
              value={telefonoTutor}
              onChange={(e) => setTelefonoTutor(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="direccionTutor" className="form-label">Dirección del Familiar o Conocido</label>
            <input
              type="text"
              className="form-control"
              id="direccionTutor"
              placeholder="Ingresar dirección del familiar"
              value={direccionTutor}
              onChange={(e) => setDireccionTutor(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="esTutor" className="form-label">
              Es Tutor o Familiar Responsable
            </label>
            <input
              type="checkbox"
              className="form-check-input"
              id="esTutor"
              checked={esTutor}
              onChange={(e) => setEsTutor(e.target.checked)}
              style={{ transform: 'scale(0.8)', marginLeft: '10px' }}  // Hizo el checkbox más pequeño
            />
          </div>
        </div>

        <div className="mb-3">
          <label htmlFor="autorizacionDatos" className="form-label">
            Autorización de Datos
          </label>
          <input
            type="checkbox"
            id="autorizacionDatos"
            checked={autorizacionDatos}
            onChange={(e) => setAutorizacionDatos(e.target.checked)}
            className="mr-2"
          />
          <label htmlFor="autorizacionDatos" className="form-label">
            Acepto el uso de mis datos
          </label>
        </div>

        <div className="mb-3">
          <label htmlFor="documentos" className="form-label">Documentos (Adjuntar)</label>
          <input
            type="file"
            className="form-control"
            id="documentos"
            onChange={(e) => setDocumentos(e.target.files)}
          />
        </div>

        <button
          type="button"
          className="bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 py-2 px-4 rounded-full w-full mb-4"
          onClick={handleRegistroClick}
        >
          Registrar Cliente
        </button>
      </form>
    </div>
  );
}

export default RegistroCliente;
