import React from 'react';
import logo from '../assets/images/logo1.png';

const Encabezado = () => {
  return (
    <header 
      className='flex justify-center items-center mb-8 p-4'
      style={{
        margin: '10px',
        background: 'linear-gradient(to right, #8e44ad, #3498db, #2ecc71)' // Gradiente de morado a azul a verde
      }}
    >
      <img src={logo} alt='Logo' className="w-25 h-25" />
    </header>
  );
};

export default Encabezado;


