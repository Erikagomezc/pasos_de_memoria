import { useRouter } from 'next/router';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import logo from '../public/logo1.png'; // Asegúrate de colocar tu imagen en la carpeta /public
import { useAuth } from '../hooks/useAuth'; // Asegúrate de que el hook exista

const USER = [
  {
    id: 1,
    username: "allisson",
    password: "121212",
    role: "admin",
  },
  {
    id: 2,
    username: "erika",
    password: "121212",
    role: "admin",
  },
  {
    id: 3,
    username: "andrea",
    password: "121212",
    role: "user",
  },
  {
    id: 4,
    username: "angie",
    password: "121212",
    role: "user",
  },
];

export default function Login() {
  const router = useRouter();
  const { user, login } = useAuth();
  const [error, setError] = useState('');

  if (user) {
    router.push('/');
  }

  function handleSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const loginObject = Object.fromEntries(formData.entries());
    const userLogin = USER.find(
      (user) =>
        user.username === loginObject.username &&
        user.password === loginObject.password
    );

    if (userLogin) {
      login(userLogin.id);
      if (userLogin.role === 'user') {
        router.push('/PageUser');
      } else if (userLogin.role === 'admin') {
        router.push('/');
      }
    } else {
      setError('Nombre de usuario o contraseña incorrectos');
    }
  }

  return (
    <div className="container-fluid vh-100 d-flex justify-content-center align-items-center bg-gradient" style={{ background: 'linear-gradient(to right, #c1e0ff, #e0c1ff, #c1ffe0)' }}>
      <div className="card p-4" style={{ maxWidth: '400px', width: '100%' }}>
        <div className="card-body">
          <Image src={logo} alt="Logo de la plataforma" width={150} height={150} className="rounded-circle border border-secondary mb-4" />
          <h2 className="text-center mb-4">Bienvenido a Pasos de Memoria</h2>
          <form onSubmit={handleSubmit}>
            {error && <p className="text-danger text-center">{error}</p>}
            <div className="mb-3">
              <label htmlFor="username" className="form-label">
                Nombre de usuario
              </label>
              <input
                type="text"
                name="username"
                id="username"
                className="form-control"
                placeholder="Nombre de usuario"
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Contraseña
              </label>
              <input
                type="password"
                name="password"
                id="password"
                className="form-control"
                placeholder="Contraseña"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary w-100 mb-3">
              Inicia sesión
            </button>
            <Link href="/register">
              <a className="text-decoration-none text-center d-block">Registro</a>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}
