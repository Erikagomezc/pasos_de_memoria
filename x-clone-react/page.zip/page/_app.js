// pages/_app.js
import 'bootstrap/dist/css/bootstrap.min.css'; // Importar Bootstrap
import '../styles/globals.css'; // Tu archivo de estilos globales (opcional)

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />;
}
