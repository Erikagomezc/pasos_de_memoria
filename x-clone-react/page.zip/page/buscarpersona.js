import { useState } from 'react';
import { useRouter } from 'next/router';

export default function CasosBusqueda() {
  const router = useRouter();

  const [casos, setCasos] = useState([
    {
      id: 1,
      cedula: '12345678',
      nombre: 'Juan Pérez',
      fecha: '2023-11-15',
      hora: '09:00 AM',
      estado: 'Normal',
    },
    {
      id: 2,
      cedula: '23456789',
      nombre: 'María González',
      fecha: '2023-11-16',
      hora: '02:30 PM',
      estado: 'Deambulando',
    },
    {
      id: 3,
      cedula: '34567890',
      nombre: 'Carlos Rodríguez',
      fecha: '2023-11-17',
      hora: '11:15 AM',
      estado: 'Normal',
    },
  ]);

  const [nuevoCaso, setNuevoCaso] = useState({
    cedula: '',
    nombre: '',
    fecha: '',
    hora: '',
    estado: 'Normal',
  });

  const handleCrearCaso = () => {
    const newId = casos.length > 0 ? casos[casos.length - 1].id + 1 : 1;
    setCasos([...casos, { id: newId, ...nuevoCaso }]);
    setNuevoCaso({
      cedula: '',
      nombre: '',
      fecha: '',
      hora: '',
      estado: 'Normal',
    });

    router.push('/resultado-busqueda');
  };

  return (
    <div className="container bg-white p-4 my-5">
      <h1 className="text-center mb-4">Gestión de Búsqueda de Clientes</h1>

      <div className="mb-4">
        <h2 className="text-center mb-3">Ingrese los Datos del Cliente en Búsqueda</h2>
        <div className="row g-3">
          <div className="col-md-6">
            <label className="form-label">Cédula:</label>
            <input
              type="text"
              value={nuevoCaso.cedula}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, cedula: e.target.value })}
              className="form-control"
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Nombre:</label>
            <input
              type="text"
              value={nuevoCaso.nombre}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, nombre: e.target.value })}
              className="form-control"
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Fecha:</label>
            <input
              type="date"
              value={nuevoCaso.fecha}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, fecha: e.target.value })}
              className="form-control"
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Hora:</label>
            <input
              type="time"
              value={nuevoCaso.hora}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, hora: e.target.value })}
              className="form-control"
            />
          </div>
          <div className="col-md-12">
            <label className="form-label">Estado del Cliente:</label>
            <select
              value={nuevoCaso.estado}
              onChange={(e) => setNuevoCaso({ ...nuevoCaso, estado: e.target.value })}
              className="form-select"
            >
              <option value="Normal">Normal</option>
              <option value="Deambulando">Deambulando</option>
            </select>
          </div>
          <div className="col-md-12">
            <button
              onClick={handleCrearCaso}
              className="btn btn-primary w-100 mt-3"
              type="button"
            >
              Ingresar Datos del Cliente en Búsqueda
            </button>
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-center mb-3">Clientes Registrados en el Sistema</h2>
        <table className="table table-striped">
          <thead className="table-light">
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Cédula</th>
              <th scope="col">Nombre</th>
              <th scope="col">Fecha</th>
              <th scope="col">Hora</th>
              <th scope="col">Estado</th>
            </tr>
          </thead>
          <tbody>
            {casos.map((caso) => (
              <tr key={caso.id}>
                <td>{caso.id}</td>
                <td>{caso.cedula}</td>
                <td>{caso.nombre}</td>
                <td>{caso.fecha}</td>
                <td>{caso.hora}</td>
                <td>{caso.estado}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
